
/* create 5 functions - display, create, search, delete & exit'
 * method for creating file, method for reading, method for deleting
 *
 create the Nail class including: ItemID, colour, price, appointment time
 create the Type class including: type of nail
 create the Extras class including: nail art, gems, removal
 create the outputs: number of extras, total cost  10% discount, time taken to complete nails 
 add in the item id, colour, price, time taken as a text file
 ensure there is pseudo code all the way through
 
 
 
 
 COULD DO - 
 create the User class which extends client and staff - you can use hobbies java for this
 Create the Nail class which extends colour and cost



 
*/
		
/*classes
		nail	
			colour 
			cost
		user - all getters and setters - use the Shape from lab10 for this
			client extends from user
			staff extends from user */