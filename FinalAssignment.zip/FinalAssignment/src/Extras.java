
public abstract class Extras extends Nail {

//new variables
private String nailArt;
private String gems;
private String removal;

public Extras(int itemID, String colour, double price, double appointmentTime, String nailArt, String gems, String removal) {
		super(itemID, colour, price, appointmentTime);
		this.nailArt = nailArt;
		this.gems = gems;
		this.removal = removal;
	
	}

public String getNailArt() {
	return nailArt;
}

public void setNailArt(String nailArt) {
	this.nailArt = nailArt;
}

public String getGems() {
	return gems;
}

public void setGems(String gems) {
	this.gems = gems;
}

public String getRemoval() {
	return removal;
}

public void setRemoval(String removal) {
	this.removal = removal;
}


