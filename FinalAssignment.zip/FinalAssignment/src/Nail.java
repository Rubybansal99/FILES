
public class Nail {

	
	// inputs across Nail
		
		public int itemID;
		public String colour;
		public double price;
		public double appointmentTime;
		public Nail (int itemID, String colour, double price, double appointmentTime)
		
		{
			super();
			this.itemID = itemID;
			this.colour = colour;
			this.price = price;
			this.appointmentTime = appointmentTime;
			
			//getters and setters
			
	}
		public int getItemID() {
			return itemID;
		}
		public void setItemID(int itemID) {
			this.itemID = itemID;
		}
		public String getColour() {
			return colour;
		}
		public void setColour(String colour) {
			this.colour = colour;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public double getAppointmentTime() {
			return appointmentTime;
		}
		public void setAppointmentTime(double appointmentTime) {
			this.appointmentTime = appointmentTime;
		}

		//toString
		@Override
		public String toString() {
			return "Nail chosen =" + itemID + ", colour " + colour + ", price" + price + ", appointment time slot = " + appointmentTime;
			
		}
}
