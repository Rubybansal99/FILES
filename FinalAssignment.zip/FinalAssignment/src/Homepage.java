import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList; 
import java.util.List;
public class Homepage {

	    
	public static void main(String[] args) throws FileNotFoundException 
		{
		int username;
		double input;
		String search;
		//ARRAY DOESNT WORK - NEED TO CHECK
		ArrayList<String> UserInputList = new ArrayList<>();
		
		// USER INPUTS - THESE WORK
		System.out.println("Hello welcome to Ruby's Nail salon. This is our complete information system database");
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter your username. It should only contain numbers.");
	    username = in.nextInt();
		in.nextLine();
		System.out.println("Thanks. Next would you like to 1.display, 2.create, 3.search, 4.delete or 5.exit?");
		input = in.nextDouble();
		in.nextLine();

		{
	   
		// THIS WORKS AS I WANT IT TO - I NEED CREATE/SEARCH/DELETE TO WORK WITH THIS
		// display (1)
		if (input == 1)
		{
			System.out.println("Thanks. Please take a look at our colour chart which lists out all of our available colours, prices and time taken to complete this set. The unique ID is what you will need to reference for each service. Please enter this next:");
			Scanner in1 = new Scanner(new FileInputStream("Data/datafile.txt"));
				while(in1.hasNextLine())
				{
					System.out.println(in1.nextLine());
				}

				in1.close();
		
		}
		
		//NEED TO FIX THIS AS IT DOESNT WORK
		// create (2)
		if (input == 2)
		{

		System.out.println("Type in new ID number");
		int itemID = in.nextInt();
		in.nextLine();
		
		System.out.println("Type in the colour you would like");
		String colour = in.toString();
		in.nextLine();
		
		System.out.println("How much would you like to spend?");
		double price = in.nextDouble();
		in.nextLine();
		
		System.out.println("How long do you have for this appointment?");
		double appointmentTime = in.nextDouble();
		in.nextLine();
	
	 // method - NEED TO LOOK INTO THE ARRAY AS IT ISNT WORKING - I NEED THIS TO PRINT TO THE TEXT FILE TOO
	
		Nail Entry = new Nail(itemID, colour, price, appointmentTime);
	    System.out.println(Entry.toString());
	    UserInputList.add(Entry);
		} 
		
		
		//NEED TO COMPLETE THIS BUT NEED TO SORT THE ARRAY FIRST
		// search (3)
		if (input == 3)
			System.out.println("What would you like to search?");
		}
		
		//NEED TO COMPLETE THIS BUT NEED TO SORT THE ARRAY FIRST
		// delete (4)
		if (input == 4) {
			
			System.out.println("Which entry would you like to delete?");
			
			UserInputList.remove(0);
		}
		
		// I THINK THIS IS FINE AND WORKS
	   // Exit code (5)
	   if (input == 5) {
	       System.out.println("Thank you for visiting us! We hope to see you again, and don't forget, customers receive 10% off their 5th visit");
	       System.exit(0); 
	   }
	  
	   
	   // I NEED TO CHECK THIS WORKS HOW IT IS SUPPOSED TO
	//exeption - IF A USER INPUTS A LETTERED USERNAME AT THE BEGINNING (SHOULD ONLY BE NUMBERS)
	   try {
			 username = (int) in.nextInt(); 
		 
		}			
		 catch (InputMismatchException ex) {

			     System.out.println("Your username shouldn't have any letters. If you don't know your username please contact us");
		 }
		{
			
		}}}

// NEED TO DO A LOOP SOMEHOW SO IF THE USER INPUTS 1-4 IT ASKS THEM THE QUESTIONS AGAIN INCASE THEY WANT TO DO SOMETHING ELSE UNTIL FINALLY THEY CLICK 5 TO EXIT

	   //for loop - need to figure this out
	   
		/*for(int input = 5; input >= 0; input--)
		{
			
			System.out.print("Thanks. Next would you like to 1.display, 2.create, 3.search, 4.delete or 5.exit?");
		}
		    System.out.println();*/
		
				

