
public abstract class Type extends Nail
	
	{
		
		//additional variable
		public String typeofNail;
		public Type (int itemID, String colour, double price, double appointmentTime, String typeofNail) 
		{
			super(itemID, colour, price, appointmentTime);
			this.typeofNail = typeofNail;
		}
		
		public String getTypeofNail() {
			return typeofNail;
	}
		public void setTypeofNail(String typeofNail) {
			this.typeofNail = typeofNail;
		}

		@Override
		public String toString() {
			return "Type of nails =" +typeofNail;
			
		}
}
